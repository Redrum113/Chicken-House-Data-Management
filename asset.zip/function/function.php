﻿<?php
error_reporting(0);

//เชื่อต่อ Database
$con = mysqli_connect("localhost", "root", "", "chicken2");
$con->set_charset("utf8");

function checkLogin($username, $password)
{
	$data = array();
	global $con;
	$sql = "select * from users where username = '" . $username . "' AND password='" . $password . "'";
	$res = mysqli_query($con, $sql);

	while ($row = mysqli_fetch_array($res)) {
		$data['id'] = $row['id'];
		$data['status'] = $row['status'];
	}
	if (!empty($data)) {

		session_start();
		$id = $data['id'];
		$_SESSION['id'] = $data['id'];
		$_SESSION['status'] = $data['status'];
		echo ("<script language='JavaScript'>
				window.location.href='dashboard.php';
				</script>");
	} else {
		echo "<script type='text/javascript'>alert('ไม่สามารถเข้าสู่ระบบได้ ');</script>";
	}

	mysqli_close($con);
}

function formatDateFull($date)
{
	if ($date == "0000-00-00") {
		return "";
	}
	if ($date == "")
		return $date;
	$raw_date = explode("-", $date);
	return  $raw_date[2] . "/" . $raw_date[1] . "/" . $raw_date[0];
}


function logout()
{
	session_start();
	session_unset();
	session_destroy();
	echo ("<script language='JavaScript'>
				window.location.href='index.php';
				</script>");
	exit();
}

function getUser($id)
{

	global $con;

	$res = mysqli_query($con, "SELECT * FROM users WHERE id = '" . $id . "'");
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveUser($firstname, $lastname, $address, $telephone, $email, $status, $username, $password, $profile)
{


	global $con;

	if ($profile != null) {
		if (move_uploaded_file($_FILES["profile"]["tmp_name"], "image/employee/" . $_FILES["profile"]["name"])) {

			$sql = "INSERT INTO users (username, password, firstname, lastname, telephone, email, address, image, status) VALUES('" . $username . "','" . $password . "','" . $firstname . "','" . $lastname . "','" . $telephone . "','" . $email . "','" . $address . "','" . $_FILES["profile"]["name"] . "','" . $status . "')";
			mysqli_query($con, $sql);
		}
	} else {

		$sql = "INSERT INTO users (username, password, firstname, lastname, telephone, email, address, status) VALUES('" . $username . "','" . $password . "','" . $firstname . "','" . $lastname . "','" . $telephone . "','" . $email . "','" . $address . "','" . $status . "')";
		mysqli_query($con, $sql);
	}
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_user.php';
		</script>");
}

function editUser($id, $firstname, $lastname, $address, $telephone, $email, $status, $username, $password, $profile)
{

	global $con;

	if ($profile != null) {
		if (move_uploaded_file($_FILES["profile"]["tmp_name"], "image/employee/" . $_FILES["profile"]["name"])) {
			$sql = "UPDATE users SET username='" . $username . "',password='" . $password . "',firstname='" . $firstname . "',lastname='" . $lastname . "',telephone='" . $telephone . "',email='" . $email . "',address='" . $address . "',image='" . $_FILES["profile"]["name"] . "',status='" . $status . "' WHERE id = '" . $id . "'";
			mysqli_query($con, $sql);
		}
	} else {
		$sql = "UPDATE users SET username='" . $username . "',password='" . $password . "',firstname='" . $firstname . "',lastname='" . $lastname . "',telephone='" . $telephone . "',email='" . $email . "',address='" . $address . "',status='" . $status . "' WHERE id = '" . $id . "'";
		mysqli_query($con, $sql);
	}

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_user.php';
		</script>");
}

function editProfile($id, $firstname, $lastname, $address, $telephone, $email, $status, $username, $password, $profile)
{

	global $con;

	if ($profile != null) {
		if (move_uploaded_file($_FILES["profile"]["tmp_name"], "image/employee/" . $_FILES["profile"]["name"])) {
			$sql = "UPDATE users SET username='" . $username . "',password='" . $password . "',firstname='" . $firstname . "',lastname='" . $lastname . "',telephone='" . $telephone . "',email='" . $email . "',address='" . $address . "',image='" . $_FILES["profile"]["name"] . "',status='" . $status . "' WHERE id = '" . $id . "'";
			mysqli_query($con, $sql);
		}
	} else {
		$sql = "UPDATE users SET username='" . $username . "',password='" . $password . "',firstname='" . $firstname . "',lastname='" . $lastname . "',telephone='" . $telephone . "',email='" . $email . "',address='" . $address . "',status='" . $status . "' WHERE id = '" . $id . "'";
		mysqli_query($con, $sql);
	}

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='edit_profile.php?id=$id';
		</script>");
}

function deleteUser($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM users WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_user.php';
	    	</script>");
}

function getAllUser()
{
	global $con;

	$res = mysqli_query($con, "SELECT * FROM users ORDER BY id DESC");

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'username' => $row['username'],
			'password' => $row['password'],
			'firstname' => $row['firstname'],
			'lastname' => $row['lastname'],
			'telephone' => $row['telephone'],
			'email' => $row['email'],
			'image' => $row['image'],
			'address' => $row['address'],
			'status' => $row['status']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentUser($id)
{

	global $con;

	$res = mysqli_query($con, "SELECT * FROM users WHERE id = '" . $id . "'");
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveFood($food_name, $food_type, $food_desc)
{

	global $con;

	$yThai = date("Y") + 543;
	$dateNow = $yThai . date("-m-d");

	$sql = "INSERT INTO foods (food_name, food_type, food_desc, update_date) VALUES('" . $food_name . "','" . $food_type . "','" . $food_desc . "','" . $dateNow . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_food.php';
		</script>");
}

function editFood($id, $food_name, $food_type, $food_desc)
{

	global $con;

	$yThai = date("Y") + 543;
	$dateNow = $yThai . date("-m-d");

	$sql = "UPDATE foods SET food_name='" . $food_name . "',food_type='" . $food_type . "',food_desc='" . $food_desc . "',update_date='" . $dateNow . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_food.php';
		</script>");
}

function deleteFood($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM foods WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_food.php';
	    	</script>");
}

function getAllFood()
{
	global $con;

	$res = mysqli_query($con, "SELECT * FROM foods ORDER BY id DESC");

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'food_name' => $row['food_name'],
			'food_type' => $row['food_type'],
			'food_desc' => $row['food_desc'],
			'update_date' => $row['update_date']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentFood($id)
{

	global $con;

	$res = mysqli_query($con, "SELECT * FROM foods WHERE id = '" . $id . "'");
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveAge($age_name)
{

	global $con;

	$sql = "INSERT INTO ages (age_name) VALUES('" . $age_name . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_age.php';
		</script>");
}

function editAge($id, $age_name)
{

	global $con;

	$sql = "UPDATE ages SET age_name='" . $age_name . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_age.php';
		</script>");
}

function deleteAge($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM ages WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_age.php';
	    	</script>");
}

function getAllAge()
{
	global $con;

	$res = mysqli_query($con, "SELECT * FROM ages ORDER BY id DESC");

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'age_name' => $row['age_name']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentAge($id)
{

	global $con;

	$res = mysqli_query($con, "SELECT * FROM ages WHERE id = '" . $id . "'");
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveBreed($breed_name)
{

	global $con;

	$sql = "INSERT INTO breeds (breed_name) VALUES('" . $breed_name . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_breed.php';
		</script>");
}

function editBreed($id, $breed_name)
{

	global $con;

	$sql = "UPDATE breeds SET breed_name='" . $breed_name . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_breed.php';
		</script>");
}

function deleteBreed($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM breeds WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_breed.php';
	    	</script>");
}

function getAllBreed()
{
	global $con;

	$res = mysqli_query($con, "SELECT * FROM breeds ORDER BY id DESC");

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'breed_name' => $row['breed_name']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentBreed($id)
{

	global $con;

	$res = mysqli_query($con, "SELECT * FROM breeds WHERE id = '" . $id . "'");
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveHouse($house_name, $house_detail, $ages_id, $foods_id)
{

	global $con;

	$yThai = date("Y") + 543;
	$dateNow = $yThai . date("-m-d");

	$sql = "INSERT INTO houses (house_name, house_detail, ages_id, foods_id, update_date) VALUES('" . $house_name . "','" . $house_detail . "','" . $ages_id . "','" . $foods_id . "','" . $dateNow . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_house.php';
		</script>");
}

function editHouse($id, $house_name, $house_detail, $ages_id, $foods_id)
{

	global $con;

	$yThai = date("Y") + 543;
	$dateNow = $yThai . date("-m-d");

	$sql = "UPDATE houses SET house_name='" . $house_name . "',house_detail='" . $house_detail . "',ages_id='" . $ages_id . "',foods_id='" . $foods_id . "',update_date='" . $dateNow . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_house.php';
		</script>");
}

function deleteHouse($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM houses WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_house.php';
	    	</script>");
}

function getAllHouse()
{
	global $con;

	$sql = "SELECT *,h.id as hid 
	FROM houses h 
	LEFT JOIN ages a ON h.ages_id = a.id
	LEFT JOIN foods f ON h.foods_id = f.id 
	ORDER BY h.id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['hid'],
			'house_name' => $row['house_name'],
			'house_detail' => $row['house_detail'],
			'food_name' => $row['food_name'],
			'age_name' => $row['age_name'],
			'update_date' => $row['update_date']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getCurrentHouse($id)
{

	global $con;

	$sql = "SELECT *,h.id as hid 
	FROM houses h 
	LEFT JOIN ages a ON h.ages_id = a.id
	LEFT JOIN foods f ON h.foods_id = f.id 
	WHERE h.id = '" . $id . "'";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveHouseInformation($houses_id, $tempurator, $moisture, $description)
{

	global $con;

	$yThai = date("Y") + 543;
	$dateNow = $yThai . date("-m-d");

	$sql = "INSERT INTO houses_info (houses_id, tempurator, moisture, description, update_date) VALUES('" . $houses_id . "','" . $tempurator . "','" . $moisture . "','" . $description . "','" . $dateNow . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='edit_house_info.php?id=$houses_id';
		</script>");
}

function getAllHouseInformation($houses_id)
{
	global $con;

	$sql = "SELECT *
	FROM houses_info
	WHERE houses_id = '" . $houses_id . "'
	ORDER BY id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();
	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'houses_id' => $row['houses_id'],
			'tempurator' => $row['tempurator'],
			'moisture' => $row['moisture'],
			'description' => $row['description'],
			'update_date' => $row['update_date']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function runNumberChicken()
{
	global $con;

	$res = mysqli_query($con, "SELECT max(id) as mid FROM chickens");
	$data = array();
	while ($row = mysqli_fetch_array($res)) {
		$data['mid'] = $row['mid'];
	}
	$run = intval($data['mid']);
	$run = $run + 1;

	if ($run == "")
		$run = 1;
	$number_order = "C-" . sprintf('%07d', $run);

	return $number_order;
	mysqli_close($con);
}

function saveChicken($chicken_number, $breeds_id, $date_egg, $date_receive, $chicken_type, $chicken_sex, $houses_id, $coop_id, $status, $date_expired,$father_id,$mother_id,$year_import,$number_import)
{

	global $con;

	$arrDate1 = explode("/", $date_egg);
	$convert_date_egg = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
	$arrDate2 = explode("/", $date_receive);
	$convert_date_receive = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];
	$arrDate3 = explode("/", $date_expired);
	$convert_date_expired = $arrDate3[2] . '-' . $arrDate3[1] . '-' . $arrDate3[0];

	$sql = "INSERT INTO chickens (chicken_number, breeds_id, date_egg, date_receive, chicken_type, chicken_sex, houses_id, coop_id, status, date_expired, father_id, mother_id, year_import, number_import) VALUES('" . $chicken_number . "','" . $breeds_id . "','" . $convert_date_egg . "','" . $convert_date_receive . "','" . $chicken_type . "','" . $chicken_sex . "','" . $houses_id . "','" . $coop_id . "','" . $status . "','" . $convert_date_expired . "','" . $father_id . "','" . $mother_id . "','" . $year_import . "','" . $number_import . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_chicken.php';
		</script>");
}

function editChicken($id, $chicken_number, $breeds_id, $date_egg, $date_receive, $chicken_type, $chicken_sex, $houses_id, $coop_id, $status, $date_expired,$father_id,$mother_id,$year_import,$number_import)
{

	global $con;

	$arrDate1 = explode("/", $date_egg);
	$convert_date_egg = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
	$arrDate2 = explode("/", $date_receive);
	$convert_date_receive = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];
	$arrDate3 = explode("/", $date_expired);
	$convert_date_expired = $arrDate3[2] . '-' . $arrDate3[1] . '-' . $arrDate3[0];

	$sql = "UPDATE chickens SET chicken_number='" . $chicken_number . "',breeds_id='" . $breeds_id . "',date_egg='" . $convert_date_egg . "',date_receive='" . $convert_date_receive . "',chicken_type='" . $chicken_type . "',chicken_sex='" . $chicken_sex . "',houses_id='" . $houses_id . "',coop_id='" . $coop_id . "',status='" . $status . "',date_expired='" . $convert_date_expired . "',father_id='" . $father_id . "',mother_id='" . $mother_id . "',year_import='" . $year_import . "',number_import='" . $number_import . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_chicken.php';
		</script>");
}

function deleteChicken($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM chickens WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_chicken.php';
	    	</script>");
}

function getAllChicken()
{
	global $con;

	$sql = "SELECT *,c.id as cid 
	FROM chickens c
	LEFT JOIN breeds b ON c.breeds_id = b.id
	LEFT JOIN houses h ON c.houses_id = h.id
	ORDER BY c.id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['cid'],
			'chicken_number' => $row['chicken_number'],
			'breed_name' => $row['breed_name'],
			'house_name' => $row['house_name'],
			'date_egg' => $row['date_egg'],
			'date_receive' => $row['date_receive'],
			'chicken_type' => $row['chicken_type'],
			'chicken_sex' => $row['chicken_sex'],
			'father_id' => $row['father_id'],
			'mother_id' => $row['mother_id'],
			'parents_type' => $row['parents_type'],
			'houses_id' => $row['houses_id'],
			'coop_id' => $row['coop_id'],
			'status' => $row['status'],
			'year_import' => $row['year_import'],
			'number_import' => $row['number_import'],
			'date_expired' => $row['date_expired']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getAllChickenInHouse($houses_id)
{
	global $con;

	$sql = "SELECT *,c.id as cid 
	FROM chickens c
	LEFT JOIN breeds b ON c.breeds_id = b.id
	LEFT JOIN houses h ON c.houses_id = h.id
	WHERE c.houses_id = '" . $houses_id . "'
	ORDER BY c.id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['cid'],
			'chicken_number' => $row['chicken_number'],
			'breed_name' => $row['breed_name'],
			'house_name' => $row['house_name'],
			'date_egg' => $row['date_egg'],
			'date_receive' => $row['date_receive'],
			'chicken_type' => $row['chicken_type'],
			'chicken_sex' => $row['chicken_sex'],
			'houses_id' => $row['houses_id'],
			'coop_id' => $row['coop_id'],
			'status' => $row['status'],
			'year_import' => $row['year_import'],
			'number_import' => $row['number_import'],
			'date_expired' => $row['date_expired']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentChicken($id)
{

	global $con;

	$sql = "SELECT *,c.id as cid 
	FROM chickens c
	LEFT JOIN breeds b ON c.breeds_id = b.id
	LEFT JOIN houses h ON c.houses_id = h.id
	WHERE c.id = '" . $id . "'";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function saveChickenInfo($chickens_id, $chest, $weight, $status, $update_date)
{

	global $con;

	$arrDate1 = explode("/", $update_date);
	$convert_update_date = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];

	$sql = "INSERT INTO chickens_info (chickens_id, chest, weight, status, update_date) VALUES('" . $chickens_id . "','" . $chest . "','" . $weight . "','" . $status . "','" . $convert_update_date . "')";
	mysqli_query($con, $sql);



	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='edit_chicken_info.php?id=$chickens_id';
		</script>");
}

function getAllChickenInfo($chickens_id)
{
	global $con;

	$sql = "SELECT * FROM chickens_info WHERE chickens_id = '" . $chickens_id . "' ORDER BY id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'chickens_id' => $row['chickens_id'],
			'chest' => $row['chest'],
			'weight' => $row['weight'],
			'status' => $row['status'],
			'update_date' => $row['update_date']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getCheckKeepEgg($houses_id, $coop_id, $date_keep)
{

	global $con;

	$sql = "SELECT count(*) as numCount FROM keeps 
	WHERE houses_id = '" . $houses_id . "' AND coop_id = '" . $coop_id . "' AND DATE(date_keep) = '" . $date_keep . "'";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function getCheckCoopEmpty($houses_id, $coop_id)
{

	global $con;

	$sql = "SELECT count(*) as numCount ,status FROM chickens 
	WHERE houses_id = '" . $houses_id . "' AND coop_id = '" . $coop_id . "'";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function confirmKeepEgg($houses_id, $coop_number, $amount_egg, $date_keep, $users_keep_id)
{
	global $con;
	unset($_SESSION["chair"]);
	unset($_SESSION["house_id"]);

	foreach ($coop_number as $key => $cn) {
		if ($cn != "") {
			$ae = $amount_egg[$key];
			$sql_detail = "INSERT INTO keeps (houses_id, coop_id, amount_egg, date_keep, users_keep_id) VALUES ('" . $houses_id . "','" . $cn . "','" . $ae . "','" . $date_keep . "','" . $users_keep_id . "')";
			mysqli_query($con, $sql_detail);
		}
	}

	echo ("<script language='JavaScript'>
		alert('บันทึกข้อมูลเรียบร้อย');
		window.location.href='select_house.php';
		</script>");
}

function getAllDataChartReport($dateStart, $dateEnd)
{
	$arrDate1 = explode("/", $dateStart);
	$convert_start_date = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
	$arrDate2 = explode("/", $dateEnd);
	$convert_end_date = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];

	global $con;
	
	/*$sql = "SELECT *,k.id as kid,sum(k.amount_egg) as kdamount_egg,k.houses_id as khouses_id
	FROM keeps k
	WHERE (k.date_keep BETWEEN '" . $convert_start_date . "' AND '" . $convert_end_date . "')
	GROUP BY k.houses_id
	ORDER BY k.id DESC";*/
	$sql = "SELECT *,sum(k.amount_egg) as sumamountegg
	FROM keeps k 
	LEFT JOIN houses h ON k.houses_id = h.id 
	LEFT JOIN ages a ON h.ages_id = a.id 
	LEFT JOIN foods f ON h.foods_id = f.id 
	WHERE (k.date_keep BETWEEN '" . $convert_start_date . "' AND '" . $convert_end_date . "')
	GROUP BY k.houses_id
	ORDER BY k.id DESC";


	$res = mysqli_query($con, $sql);

	$data = array();

	$arrData = array(
		"chart" => array(
			"caption" => "รายงานสถิติการเก็บไข่",
			"paletteColors" => "#0075c2",
			"bgColor" => "#ffffff",
			"borderAlpha" => "20",
			"canvasBorderAlpha" => "0",
			"usePlotGradientColor" => "0",
			"plotBorderAlpha" => "10",
			"showXAxisLine" => "1",
			"xAxisLineColor" => "#999999",
			"showValues" => "0",
			"divlineColor" => "#999999",
			"divLineIsDashed" => "1",
			"showAlternateHGridColor" => "0"
		)
	);

	$jsonArray = array();

	$arrData["data"] = array();
	//

	while ($row = mysqli_fetch_array($res)) {
		//$hid = "โรงเรือน" . $row["khouses_id"];
		array_push(
			$arrData["data"],
			array(

				"label" => $row["house_name"],
				"value" => $row["sumamountegg"]
			)
		);
	}

	$jsonEncodedData = json_encode($arrData);

	return $jsonEncodedData;

	mysqli_close($con);
}

function getAllDataReport($dateStart, $dateEnd)
{
	global $con;

	$arrDate1 = explode("/", $dateStart);
	$convert_start_date = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
	$arrDate2 = explode("/", $dateEnd);
	$convert_end_date = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];

	$sql = "SELECT *,sum(k.amount_egg) as sumamountegg
	FROM keeps k 
	LEFT JOIN houses h ON k.houses_id = h.id 
	LEFT JOIN ages a ON h.ages_id = a.id 
	LEFT JOIN foods f ON h.foods_id = f.id 
	WHERE (k.date_keep BETWEEN '" . $convert_start_date . "' AND '" . $convert_end_date . "')
	GROUP BY k.houses_id
	ORDER BY k.id DESC";
	
	//print_r($sql);
	//die();

	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['kid'],
			'house_name' => $row['house_name'],
			'food_type' => $row['food_type'],
			'age_name' => $row['age_name'],
			'house_detail' => $row['house_detail'],
			'amount_egg' => $row['sumamountegg']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getAllDataKeepEgg($search_date)
{
	global $con;

	$arrDate2 = explode("/", $search_date);
	$convert_search_date = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];

	$sql = "SELECT *,k.id as kid,k.update_date as kupdate_date,k.date_keep as kdate_keep
	FROM keeps k
	LEFT JOIN houses h ON k.houses_id = h.id
	LEFT JOIN chickens c ON k.coop_id = c.coop_id 
	WHERE DATE(k.date_keep) = '" . $convert_search_date . "' 
	ORDER BY k.id ASC";


	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['kid'],
			'house_name' => $row['house_name'],
			'coop_id' => $row['coop_id'],
			'chicken_number' => $row['chicken_number'],
			'amount_egg' => $row['amount_egg'],
			'date_keep' => $row['kdate_keep'],
			'users_keep_id' => $row['users_keep_id'],
			'users_edit_id' => $row['users_edit_id'],
			'update_date' => $row['kupdate_date']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getCurrentKeep($id)
{

	global $con;

	$sql = "SELECT *,k.id as kid
	FROM keeps k
	LEFT JOIN houses h ON k.houses_id = h.id
	LEFT JOIN chickens c ON k.coop_id = c.coop_id 
	WHERE k.id = '" . $id . "' ";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function  editAmountEgg($id, $amount_egg, $update_date, $users_edit_id)
{

	global $con;

	$arrDate1 = explode("/", $update_date);
	$convert_update_date = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];

	$sql = "UPDATE keeps SET amount_egg='" . $amount_egg . "',update_date='" . $convert_update_date . "',users_edit_id='" . $users_edit_id . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='search_egg.php';
		</script>");
}

function getPdfDataReportEgg($houses_id, $dateStart, $dateEnd)
{
	global $con;

	$arrDate1 = explode("/", $dateStart);
	$convert_start_date = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
	$arrDate2 = explode("/", $dateEnd);
	$convert_end_date = $arrDate2[2] . '-' . $arrDate2[1] . '-' . $arrDate2[0];

	$sql = "SELECT *
	FROM keeps k
	LEFT JOIN houses h ON k.houses_id = h.id  
	LEFT JOIN chickens c ON k.coop_id = c.coop_id 
	LEFT JOIN breeds b ON c.breeds_id = b.id 
	WHERE (k.date_keep BETWEEN '" . $convert_start_date . "' AND '" . $convert_end_date . "') AND k.houses_id = '" . $houses_id . "'
	ORDER BY k.date_keep ASC";

	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'date_keep' => $row['date_keep'],
			'id' => $row['kid'],
			'house_name' => $row['house_name'],
			'coop_id' => $row['coop_id'],
			'chicken_type' => $row['chicken_type'],
			'breed_name' => $row['breed_name'],
			'chicken_number' => $row['chicken_number'],
			'amount_egg' => $row['amount_egg'],
		
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function runNumberParrent()
{
	global $con;

	$res = mysqli_query($con, "SELECT max(id) as mid FROM parents");
	$data = array();
	while ($row = mysqli_fetch_array($res)) {
		$data['mid'] = $row['mid'];
	}
	$run = intval($data['mid']);
	$run = $run + 1;

	if ($run == "")
		$run = 1;
	$number_order = "P-" . sprintf('%07d', $run);

	return $number_order;
	mysqli_close($con);
}

function saveParrent($parents_number,$parents_type)
{

	global $con;

	$sql = "INSERT INTO parents (parents_number, parents_type) VALUES('" . $parents_number . "','" . $parents_type . "')";
	mysqli_query($con, $sql);

	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('เพิ่มข้อมูลเรียบร้อย');
		window.location.href='manage_parent.php';
		</script>");
}

function editParrent($id,$parents_number,$parents_type)
{
	global $con;

	$sql = "UPDATE parents SET parents_number='" . $parents_number . "',parents_type='" . $parents_type . "' WHERE id = '" . $id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('แก้ไขข้อมูลเรียบร้อย');
		window.location.href='manage_parent.php';
		</script>");
}

function deleteParrent($id)
{
	global $con;

	mysqli_query($con, "DELETE FROM parents WHERE id='" . $id . "'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
			alert('ลบข้อมูลเรียบร้อย');
	    	window.location.href='manage_parent.php';
	    	</script>");
}

function getAllParrent()
{
	global $con;

	$sql = "SELECT *
	FROM parents
	ORDER BY id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'parents_number' => $row['parents_number'],
			'parents_type' => $row['parents_type']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}

function getAllParrentType($parents_type)
{
	global $con;

	$sql = "SELECT *
	FROM parents
	WHERE parents_type = '".$parents_type."'
	ORDER BY id DESC";
	$res = mysqli_query($con, $sql);

	$data = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'id' => $row['id'],
			'parents_number' => $row['parents_number'],
			'parents_type' => $row['parents_type']
		);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);
}


function getCurrentParrent($id)
{

	global $con;

	$sql = "SELECT *
	FROM parents
	WHERE id = '" . $id . "'";

	$res = mysqli_query($con, $sql);
	$result = mysqli_fetch_array($res, MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);
}

function updateStatusChicken($houses_id)
{

	global $con;

	$sql = "UPDATE chickens SET status='2' WHERE houses_id = '" . $houses_id . "'";
	mysqli_query($con, $sql);

	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('[ันทึกข้อมูลเรียบร้อย');
		window.location.href='chicken_in_house.php?houses_id=$houses_id';
		</script>");
}
?>
