
<?php
require("function.php");
$conn = mysqli_connect("localhost","root","","chicken2");
$conn->set_charset("utf8");
require_once('excel_lib/php-excel-reader/excel_reader2.php');
require_once('excel_lib/SpreadsheetReader.php');

if(isset($_POST["Import"])){
  $allowedFileType = ['application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
  $houses_id = $_POST["houses_id"];
  $breeds_id = $_POST["breeds_id"];
  $number_import = $_POST["number_import"];
  $yThai = date("Y")+543;
  $dateNow = $yThai.date("-m-d");
  
  if(in_array($_FILES["file"]["type"],$allowedFileType)){
    $targetPath = 'uploads/'.$_FILES['file']['name'];
    move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);

    $Reader = new SpreadsheetReader($targetPath);

    $sheetCount = count($Reader->sheets());

    for($i=0;$i<$sheetCount;$i++)
    {
      $Reader->ChangeSheet($i);

      foreach ($Reader as $Row)
      {
        $runNumber = runNumberChicken();

        $chicken_type = "";
        if(isset($Row[0])) {
          $chicken_type = mysqli_real_escape_string($conn,$Row[0]);
        }

        $chicken_sex = "";
        if(isset($Row[1])) {
          $chicken_sex = mysqli_real_escape_string($conn,$Row[1]);
        }

        $date_egg = "";
        if(isset($Row[2])) {
          $date_egg = mysqli_real_escape_string($conn,$Row[2]);
          $arrDate1 = explode("/", $date_egg);
	        $convert_date_egg = $arrDate1[2] . '-' . $arrDate1[1] . '-' . $arrDate1[0];
        }
        for ($x = 100; $x >= 1; $x--) {
          $sql_check = "select count(*) as numCount from chickens where houses_id  = '" . $houses_id . "' AND coop_id = '".$x."'";
          $res = mysqli_query($conn, $sql_check);

          while ($row = mysqli_fetch_array($res)) {
            $data['numCount'] = $row['numCount'];
          }
          if($data['numCount'] == 0){
            $coop_id = $x;
          }
        }
        


        if (!empty($chicken_type) || !empty($chicken_sex) || !empty($date_egg)) {
          
          $query = "insert into chickens (chicken_number, breeds_id, date_egg, date_receive, chicken_type, chicken_sex, houses_id, coop_id, status, year_import, number_import) 
          values('".$runNumber."','".$breeds_id."','".$convert_date_egg."','".$dateNow."','".$chicken_type."','".$chicken_sex."','".$houses_id."','".$coop_id."','1','".$yThai."','".$number_import."')";
          $result = mysqli_query($conn, $query);

          if (! empty($result)) {
            echo ("<script language='JavaScript'>
              alert('CSV File has been successfully Imported.');
              window.location.href='../chicken_in_house.php?houses_id=$houses_id';
              </script>"); 
          } else {
            echo ("<script language='JavaScript'>
              alert('Invalid File:Please Upload CSV File.');
              window.location.href='../import_chicken.php';
              </script>"); 
          }
        }
      }


    }
  }
  


    /*$filename=$_FILES["file"]["tmp_name"];    


     if($_FILES["file"]["size"] > 0)
     {
        $file = fopen($filename, "r");
          while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
           {
          
            $sql = "INSERT INTO student (student_id, firstname_th, lastname_th, class_room, room_number) values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$cr."','".$rn."')";
            $result = mysqli_query($con, $sql);



        if(!isset($result))
        {
              echo ("<script language='JavaScript'>
        alert('Invalid File:Please Upload CSV File.');
          window.location.href='../import_student.php';
          </script>"); 
        }
        else {
          echo ("<script language='JavaScript'>
        alert('CSV File has been successfully Imported.');
          window.location.href='../manage_student.php';
          </script>"); 
        }
           }
      
           fclose($file); 
         }*/
       }



       ?>